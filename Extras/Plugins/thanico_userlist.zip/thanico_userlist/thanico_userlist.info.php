<?php
/*LICENSE DO WHAT THE F* YOU WANT WITH THIS !

JUST PLEASE KEEP MY INFOS :
https://github.com/ThaNico
thanico.dev [at] gmail.com

Rewritten from JOJOManLV's userlist v.0.0.3
https://github.com/JOJOManLV/codofUserList
From this commit: 1593cd4f48856d884b03c015a7b0c4d4fc934c27
*/

  $info['name'] = 'ThaNico\'s userlist';
  $info['plugin_type']= 'block';
  $info['description'] = 'Shows a customizable userlist<br/>
  Rewritten from JOJOManLV\'s userlist v.0.0.3<br/>
  Last updated : 09/2015';
  $info['version'] = '1.0.0';
  $info['author'] = "ThaNico";
  $info['author_url'] = 'https://github.com/ThaNico';
  $info['license'] = '';
  $info['core'] = '3.x';
  