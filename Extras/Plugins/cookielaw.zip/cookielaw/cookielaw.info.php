<?php

$info['name'] = 'Cookielaw';
$info['description'] = 'A simple Cookielaw plugin for Europe';
$info['version'] = '1.x';
$info['author'] = "Andreas Holzer / WebCrew";
$info['author_url'] = 'https://crazymates.de';
$info['license'] = 'GNU GPL V3';
$info['core'] = '1.x';
