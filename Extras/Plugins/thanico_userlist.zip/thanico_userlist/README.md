Hi !

--------------------------
HOW TO INSTALL ?
--------------------------
0. I just downloaded my own release, GitHub calls the folder thanico_userlist-1.0.0, please RENAME it to thanico_userlist, or it WON'T WORK !

1. Move the folder 'thanico_userlist' to sites/default/plugins/
You should have sites/default/plugins/thanico_userlist/...

2. Go to your admin panel -> plugins and install thanico_userlist !

3. Enable it !


--------------------------
HOW TO DISPLAY THE LIST ?
--------------------------
Create a page if you want to, then create the plugin block on the page you've created or anywhere you want

If you don't know how to do these things don't worry :)
Just follow the steps inside the folder 'screenshots' !


--------------------------
HOW TO CUSTOMIZE ?
--------------------------
Just checkout thanico_userlist.config.php, everything you need is inside !


--------------------------
PROBABLE PROBLEMS :
--------------------------
Q: I set up my language in the config file but it shows in english, help me !
A: That's because your lang isn't configured in thanico_userlist.lang.php
I just put the french and english translations, you're welcome to add yours
You just have to copy what I've done for a lang and change it


--------------------------
CONTACT
--------------------------
Feel free to follow me !
If you have any question or idea : thanico.dev [at] gmail.com