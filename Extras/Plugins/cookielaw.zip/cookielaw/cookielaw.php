<?php

/*
 * @CODOLICENSE
 */

function add_cookielaw_js()
{

    add_js(PLUGIN_PATH . 'cookielaw/assets/js/cookielaw.js', array('name' => 'cookielaw.js', 'type' => 'defer'));
    add_css(PLUGIN_PATH . 'cookielaw/assets/css/cookielaw.css', array('name' => 'cookielaw.css'));
}

//Below hooks are called on all pages
CODOF\Hook::add('before_site_head', "add_cookielaw_js");


