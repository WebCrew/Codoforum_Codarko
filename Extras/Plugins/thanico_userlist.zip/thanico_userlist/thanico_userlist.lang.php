<?php

$userlist_lang['en_US']['id'] = '#';
$userlist_lang['en_US']['avatar'] = 'Avatar';
$userlist_lang['en_US']['name'] = 'Username';
$userlist_lang['en_US']['nbposts'] = 'Posts';
$userlist_lang['en_US']['nbviews'] = 'Profile views';
$userlist_lang['en_US']['role'] = 'Group';

?>